package com.example.appaniversario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import Models.Aniversario;

public class MainActivity extends AppCompatActivity {

    List<Aniversario> lstAniversario = new ArrayList<Aniversario>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarLista();
    }
    private void inicializarLista() {
        lstAniversario.add(new Aniversario("Aline", "Rua dos bobos", "1995-05-02"));
        lstAniversario.add(new Aniversario("José", "Rua Feliz", "2000-05-02"));
        lstAniversario.add(new Aniversario("Manuel", "Rua bobos", "1997-05-02"));
        lstAniversario.add(new Aniversario("Babi", "Rua Azul", "1958-05-02"));

        bindListaAniversario();
    }
    private void bindListaAniversario() {
        ArrayAdapter<Aniversario> aa = new ArrayAdapter<Aniversario>(this, android.R.layout.simple_list_item_1, lstAniversario);
        ListView lv = (ListView) findViewById(R.id.listaContactos);
        lv.setAdapter(aa);

    }
}