package Models;

import static java.util.UUID.randomUUID;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Aniversario {

    public static final int MAXNOME =128;
    public static final int MAXMORADA =128;

    private String _id; //GUID global unic identifier
    private String _nome; // quando nao se diz de é public ou private é automaticamente private
    private String _morada;
    private Date _dtNascimento;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public Aniversario() {
        _id = randomUUID().toString();
        setNome("");
        setMorada("");
        try {
            _dtNascimento = sdf.parse("1900-01-01");
        }
        catch (ParseException ex) {

        }
    }

    public Aniversario (String nome, String morada, String dtNascimento) {
        _id = randomUUID().toString();
        setNome(nome);
        setMorada(morada);
        setDtNascimento(dtNascimento);
    }

    //o ID nao tera setter
    public String getId() {return _id;}

    public void setNome(String nome) {
        _nome = nome;
        if (_nome.length() == 0) _nome = "Não definido";
        if (nome.length() > MAXNOME) _nome = _nome.substring(0, MAXNOME-1);
    }
    public String getNome() {return _nome;}

    public void setMorada(String morada) {
        _morada = morada;
        if (_morada.length() == 0) _morada = "A definir";
        if (morada.length() > MAXMORADA) _morada = _morada.substring(0, MAXMORADA-1);
    }
    public String getMorada() {return _morada;}

    public void setDtNascimento(String dtNascimento) {
        try {
            _dtNascimento = sdf.parse(dtNascimento);
        }
        catch (Exception ex){
            _dtNascimento = new Date("1900-01-01");
        }
    }
    public String getDtNascimento() {return _dtNascimento.toString();}

    public String toString() {
        return getNome() + " " + sdf.format(_dtNascimento); }


}
